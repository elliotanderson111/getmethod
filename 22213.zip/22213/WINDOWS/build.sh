#!/bin/bash
echo "[+] Compiling 64-bit Windows executable..."
x86_64-w64-mingw32-gcc -o windows_crypto_service_x64.exe tor2binary.c \
    -lwininet -ladvapi32 -lws2_32 -lole32 -loleaut32 -lshell32 \
    -s -O2 -mwindows -fno-ident -fno-asynchronous-unwind-tables \
    -Wl,--strip-all,--nxcompat,--dynamicbase,--no-seh \
    -D_WIN32_WINNT=0x0600 -DWINVER=0x0600

echo "[+] Compiling 32-bit Windows executable..."
i686-w64-mingw32-gcc -o windows_crypto_service_x86.exe tor2binary.c \
    -lwininet -ladvapi32 -lws2_32 -lole32 -loleaut32 -lshell32 \
    -s -O2 -mwindows -fno-ident -fno-asynchronous-unwind-tables \
    -Wl,--strip-all,--nxcompat,--dynamicbase,--no-seh \
    -D_WIN32_WINNT=0x0600 -DWINVER=0x0600

echo "[+] Checking file properties..."
ls -la windows_crypto_service_*.exe
echo ""
echo "[+] Done. Executables ready for deployment."