#!/bin/bash

# Path to the file (replace the rest of the path after home)
FILE="$HOME/getmethod/22213/BORE"
TARGET="/usr/bin/bore"

# Check if file exists
if [ ! -f "$FILE" ]; then
    echo "Error: File not found at $FILE"
    exit 1
fi

# Make the file executable
sudo chmod +x "$FILE"

# Copy to /usr/bin and set executable
sudo cp "$FILE" "$TARGET"
sudo chmod +x "$TARGET"

echo "Successfully installed bore to $TARGET"