#!/bin/bash

TARGET="/usr/bin/bore"

# Find the BORE directory dynamically
BORE_DIR=$(find /home -type d -path "*/getmethod/22213/BORE" 2>/dev/null | head -n1)

if [ -z "$BORE_DIR" ]; then
    echo "Error: BORE directory not found"
    exit 1
fi

# Set the file path
BORE_FILE="$BORE_DIR/bore"

# Check if the file exists
if [ ! -f "$BORE_FILE" ]; then
    echo "Error: bore file not found inside $BORE_DIR"
    exit 1
fi

# Make the file executable
chmod +x "$BORE_FILE"

# Copy to /usr/bin and set executable
sudo cp "$BORE_FILE" "$TARGET"
sudo chmod +x "$TARGET"

echo "Successfully installed bore to $TARGET"